package teste;

import vetor.Vetor;

public class Aula03 {
	public static void main(String[] args) {

		Vetor vetor = new Vetor(5);

		vetor.adiciona("elemento 1");
		
	}	
}
